package com.example.bit_fly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
