// import 'package:bit_fi/welcome.dart';
// import 'package:bitcoin_ticker/welcome.dart';
import 'package:flutter/material.dart';
import 'price_screen.dart';
import 'welcome.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
          primaryColor: Colors.lightBlue,
          scaffoldBackgroundColor: Colors.white),
      home: WelcomeScreen(),
    );
  }
}
